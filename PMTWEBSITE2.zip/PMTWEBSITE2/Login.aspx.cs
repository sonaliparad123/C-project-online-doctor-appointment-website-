﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OleDb;
public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if ((Session["UserName"] == null) && (Session["Password"] == null)) 
        {
            user.Text = "";
        
        }else
        {

        String login = (String)(Session["UserName"]);
        String pass = (String)(Session["Password"]);
        user.Text = "Hiii  "+login.ToString();
        }

    }
    protected void LoginBtn_Click(object sender, EventArgs e)
    {
        //Session["UserName"] = rname;
       // Session["Password"] = pass;
        if (TextBox1.Text == "admin" && TextBox2.Text == "admin")
        {
            Response.Redirect("~/Admin/DoctorDetails.aspx");
        }
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["connection"].ToString();
        String values = Convert.ToString( TextBox1.Text);
        String values1 = Convert.ToString(TextBox2.Text);
        con.Open();
        OleDbCommand cmd = new OleDbCommand("select name from registration where name='" + values + "' and password='"+values1+"'", con);

        OleDbDataReader rs = cmd.ExecuteReader();
       

        if (rs.Read() ) 
        {
            Session["UserName"] = values;
          //  OleDbCommand cmd1 = new OleDbCommand("select password from registration where password='" + values1 + "'", con);

         //   OleDbDataReader rs1 = cmd1.ExecuteReader();
          //  if (rs1.Read())
         //   {
                Session["Password"] = values1;
                Session["status"] = "inprocess";
                String login = (String)(Session["UserName"]);
                String pass = (String)(Session["Password"]);
                user.Text = "Hiii  " + login.ToString();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert(' Login');</script>");
                Response.Redirect("~/Home.aspx");
            }
            else
            {
                Session["UserName"] = null;
                Session["Password"] = null;
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert(' Inavalid Login');</script>");
               
               
                

            }
           // Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert(' Login');</script>");
        
      
       
        con.Close();
    }
}
// Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Invalid Login');</script>");
