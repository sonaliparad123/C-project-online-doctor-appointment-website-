﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OleDb;
public partial class Appointment : System.Web.UI.Page
{
    String values;
    String rid;
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!IsPostBack)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            Panel5.Visible = false;
            

            if (Session["UserName"] == null && Session["Password"] == null)
            {
                Response.Redirect("~/Login.aspx");
            }
            else
            {
                String login = (String)(Session["UserName"]);

                user.Text = "Hiii  " + login.ToString();
            }
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["appintmentes"].ToString();
            con.Open();
            OleDbCommand cmd1 = new OleDbCommand("select count(*) from appointment", con);
            int returnValue = (int)cmd1.ExecuteScalar();
            int countValue = returnValue + 1;
            rid = countValue.ToString();
            con.Close();

        }
    }
    protected void next_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = true;
        Panel3.Visible = false;
        Panel4.Visible = false;
        doctorname.Text = DropDownList2.SelectedValue;
        values = DropDownList2.SelectedValue.ToString();
        TextBox3.Text = values.ToString();
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["connection"].ToString();

        OleDbCommand cmd = new OleDbCommand("select ID,dname from doctor where specialty='"+values+"'", con);
        con.Open();
        DropDownList1.DataSource = cmd.ExecuteReader();
        DropDownList1.DataBind();
        con.Close();
        



    }
    protected void prev_Click(object sender, EventArgs e)
    {//prev2
        Panel1.Visible = true;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = false;
    }
   
    protected void next2_Click(object sender, EventArgs e)
    {//next2
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = true;
        Panel4.Visible = false;


        String value1 = DropDownList1.SelectedItem.Text;
        TextBox2.Text = value1.ToString();
       // Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Selected');</script>");
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["connection"].ToString();

        OleDbCommand cmd = new OleDbCommand("select ID,qual from doctor where dname='" + value1 + "'", con);
        con.Open();
        DropDownList4.DataSource = cmd.ExecuteReader();
        DropDownList4.DataBind();
        con.Close();
       
    }
   
    protected void prev1_Click1(object sender, EventArgs e)
    {//prev 3
        Panel1.Visible = false;
        Panel2.Visible = true;
        Panel3.Visible = false;
        Panel4.Visible = false;
    }
    protected void next3_Click(object sender, EventArgs e)
    {//next4
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = true;
        String qualification = DropDownList4.SelectedItem.Text;
        String dname = DropDownList1.SelectedItem.Text;
        String special = TextBox3.Text.ToString();
        String login = (String)(Session["UserName"]);
        txtdname.Text = dname;
        txtqual.Text = qualification;
        txtspecial.Text = special;
        pname.Text = login;

    }
    protected void Button1_Click(object sender, EventArgs e)
    {//prev 4
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = true;
        Panel4.Visible = false;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {//submit
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = true;


        ///////////////////////


        OleDbConnection con1 = new OleDbConnection();
        con1.ConnectionString = ConfigurationManager.ConnectionStrings["appintmentes"].ToString();
        con1.Open();
        OleDbCommand cmd2 = new OleDbCommand("select count(*) from appointment", con1);
        int returnValue = (int)cmd2.ExecuteScalar();
        int countValue = returnValue + 1;
        rid = countValue.ToString();
        con1.Close();

        ///////////////////////

        String value1 = DropDownList3.SelectedItem.Text;
        String date1 = txtdate.Text.ToString();
        String pname1 = (String)(Session["UserName"]);
        String dname1 = txtdname.Text;

        // Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Selected');</script>");
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["appintmentes"].ToString();
        con.Open();
        OleDbCommand cmd = new OleDbCommand("select * from appointment where time='" + value1 + "' and date= '" + date1 + "' and dname= '" + dname1 + "'", con);
        OleDbDataReader dr;
         dr =cmd.ExecuteReader();
        
        if (dr.Read())
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Change Time OR Date');</script>");
            con.Close();
        }
       

        else{   // Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Change Time');</script>");
            con.Close();
            Session["status"] = "completed";
            String status = (String)(Session["status"]);
        OleDbConnection con2 = new OleDbConnection();
        con2.ConnectionString = ConfigurationManager.ConnectionStrings["appintmentes"].ToString();
        con2.Open();
        
            OleDbCommand cmd3 = new OleDbCommand("insert into appointment values('" + rid + "','" + dname1 + "','" + pname1 + "','" + value1 + "','" + date1 + "','"+status+"')", con2);
            cmd3.ExecuteNonQuery();
            con2.Close();
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Appointment Saved');</script>");
            
        }
       
    }

   
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtdate.Text = Calendar1.SelectedDate.ToString("d");
        Calendar1.Visible = false;
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;

        }
        else
        {
            Calendar1.Visible = true;

        }
        
    }
    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date<DateTime.Now.Date || e.Day.IsOtherMonth)
        {
            e.Day.IsSelectable = false;
            e.Cell.BackColor = System.Drawing.Color.Red;

        }

    }


    protected void show_Click(object sender, EventArgs e)
    {
        String s1 = Convert.ToString(DropDownList5.SelectedItem.Text);
        String login = (String)(Session["UserName"]);
        String d1 = Convert.ToString(DropDownList6.SelectedItem.Text);//statusasdasdf123
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["statusasdasdf123"].ToString();
        String cancel = "cancel";
        con.Open();
        OleDbCommand cmd = new OleDbCommand("update appointment set status='" + cancel + "' where dname= '" + d1 + "' and name='" + login + "'", con);
        cmd.ExecuteNonQuery();
        Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Appointment Cancel Successfullly');</script>");

     

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        doctorname.Text = DropDownList5.SelectedValue;
        values = DropDownList5.SelectedValue.ToString();
        
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["connection"].ToString();

        OleDbCommand cmd = new OleDbCommand("select ID,dname from doctor where specialty='" + values + "'", con);
        con.Open();
        DropDownList6.DataSource = cmd.ExecuteReader();
        DropDownList6.DataBind();
        con.Close();
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = false;
        Panel5.Visible = true;
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
       
        Panel5.Visible = false;
        Panel1.Visible = true;
    }
}
