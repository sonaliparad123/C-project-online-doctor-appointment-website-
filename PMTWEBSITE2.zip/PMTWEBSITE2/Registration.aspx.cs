﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OleDb;
using System.Configuration;
public partial class Registration : System.Web.UI.Page

{
    String rid;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserName"] == null && Session["Password"] == null)
        {
        }
        else
        {
            String login = (String)(Session["UserName"]);

            user.Text = "Hiii  " + login.ToString();
        }
        
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["hospitalregistration"].ToString();
        con.Open();
        OleDbCommand cmd1 = new OleDbCommand("select count(*) from registration",con);
        int returnValue = (int)cmd1.ExecuteScalar();
        int countValue = returnValue + 1;
        rid = countValue.ToString();
      

    }
    protected void register_Click(object sender, EventArgs e)
    {
       
 
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["hospitalregistration"].ToString();
        con.Open();
        String rname=Convert.ToString(name.Text);
        String rphone=Convert.ToString(phone.Text);
        String radd=Convert.ToString(address.Text);
        String gen=Convert.ToString(gender.SelectedValue);
        String rage = Convert.ToString(age.Text);
        String pass = Convert.ToString(password.Text);

        //session created
        

       OleDbCommand cmd = new OleDbCommand("insert into registration values('"+rid+"','" + rname + "','" + rphone + "','" + radd + "','" + gen + "','" + rage + "','" + pass + "')",con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("~/Login.aspx");

           
        
    }
    protected void reset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Url.AbsoluteUri);
    }
}
