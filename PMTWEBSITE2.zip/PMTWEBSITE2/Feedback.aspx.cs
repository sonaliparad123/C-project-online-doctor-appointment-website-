﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OleDb;
public partial class Feedback : System.Web.UI.Page
{
    String rid;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserName"] == null && Session["Password"] == null)
        {
        }
        else
        {
            String login = (String)(Session["UserName"]);

            user.Text = "Hiii  " + login.ToString();
        }
        
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["feedbackasd"].ToString();
        con.Open();
        OleDbCommand cmd1 = new OleDbCommand("select count(*) from feedback", con);
        int returnValue = (int)cmd1.ExecuteScalar();
        int countValue = returnValue + 1;
        rid = countValue.ToString();
      
    }
    protected void submit_Click(object sender, EventArgs e)
    {
        String name = fname.Text;
        String address = faddress.Text;
        String gender = fgender.SelectedItem.Text;
        String age = fage.Text;
        String moblie = fmoblie.Text;
        String comments = TextBox1.Text;
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["feedbackasd"].ToString();
        con.Open();
        OleDbCommand cmd = new OleDbCommand("insert into feedback values('" + rid + "','" + name + "','" + address + "','" + gender + "','" + age + "','" + moblie + "','" + comments + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("~/Home.aspx");
    }
}
