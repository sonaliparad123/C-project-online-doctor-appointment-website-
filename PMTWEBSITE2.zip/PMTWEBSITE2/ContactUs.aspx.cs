﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OleDb;
public partial class ContactUs : System.Web.UI.Page
{
    String rid;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserName"] == null && Session["Password"] == null)
        {
        }
        else
        {
            String login = (String)(Session["UserName"]);

            user.Text = "Hiii  " + login.ToString();
        }
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["contactasd"].ToString();
        con.Open();
        OleDbCommand cmd1 = new OleDbCommand("select count(*) from contact", con);
        int returnValue = (int)cmd1.ExecuteScalar();
        int countValue = returnValue + 1;
        rid = countValue.ToString();
    }
    protected void submit_Click(object sender, EventArgs e)
    {
        String name = cname.Text;
        String email = cemail.Text;
        String mes = message.Text;
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["contactasd"].ToString();
        con.Open();
        OleDbCommand cmd = new OleDbCommand("insert into contact values('" + rid + "','" + name + "','" + email + "','" + mes + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Contact Saved');</script>");
      
    }
}
