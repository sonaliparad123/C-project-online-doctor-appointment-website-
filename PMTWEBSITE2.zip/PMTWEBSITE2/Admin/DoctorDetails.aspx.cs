﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OleDb;
public partial class Admin_DoctorDetails : System.Web.UI.Page
{
    String rid;
    protected void Page_Load(object sender, EventArgs e)
    {
        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["adddoctor"].ToString();
        con.Open();
        OleDbCommand cmd1 = new OleDbCommand("select count(*) from doctor", con);
        int returnValue = (int)cmd1.ExecuteScalar();
        int countValue = returnValue + 1;
        rid = countValue.ToString();
        TextBox1.Text = rid.ToString();
      
    }
    protected void reset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Url.AbsoluteUri);
    }
    protected void add_Click(object sender, EventArgs e)
    {

        OleDbConnection con = new OleDbConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["adddoctor"].ToString();
        con.Open();
      
        String dname = Convert.ToString(TextBox2.Text);
        String quall = Convert.ToString(TextBox3.Text);
        String spe = Convert.ToString(TextBox4.Text);

        OleDbCommand cmd = new OleDbCommand("insert into doctor values('" + rid + "','" + dname + "','" + quall + "','" + spe + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert(' Saved');</script>");
               
    }
    protected void update_Click(object sender, EventArgs e)
    {

    }
    protected void delete_Click(object sender, EventArgs e)
    {

    }
}
