﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_Reports : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
   
    protected void Feedback_Click(object sender, EventArgs e)
    {
       
        Response.Redirect("~/ReportFeedback.aspx");
    }
    protected void appointment_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ReportAppointment.aspx");
    }
    protected void registration_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ReportRagistration.aspx");
    }
    protected void Doctor_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ReportDoctor.aspx");
    }
    protected void contactus_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ReportContact.aspx");
    }
    protected void DailyAppointment_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ReportDailyAppointment.aspx");
    }
    protected void MonthlyAppoint_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ReportMonthalyAppoint.aspx");
    }
    
    protected void doctorwise_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Default.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ReportCancel.aspx");
    }
}
